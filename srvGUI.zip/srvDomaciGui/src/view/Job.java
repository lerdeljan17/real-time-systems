package view;

public class Job {
	private int id;
	private int startTime;
	private int finsihTime;
	public Job(int id, int startTime, int finsihTime) {
		super();
		this.id = id;
		this.startTime = startTime;
		this.finsihTime = finsihTime;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getStartTime() {
		return startTime;
	}
	public void setStartTime(int startTime) {
		this.startTime = startTime;
	}
	public int getFinsihTime() {
		return finsihTime;
	}
	public void setFinsihTime(int finsihTime) {
		this.finsihTime = finsihTime;
	}
	
}
