package view;

import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class DisplayOrder extends JFrame {
		DisplayGraphics m;  
	 public DisplayOrder(ArrayList<Job> jobs) {
		 setSize(400,400);
		 m=new DisplayGraphics(jobs);
		 add(m);
		 setVisible(true);
	 }

}
