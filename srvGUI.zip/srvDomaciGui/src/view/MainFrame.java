package view;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.ClipboardOwner;
import java.awt.datatransfer.Transferable;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowListener;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.LookAndFeel;



public class MainFrame extends JFrame {
	private static MainFrame instance = null;
	private JTextField startnoVreme;
	private JTextField vremeIzvrsavanja;
	private JTextField deadLine;
	private JTextField heuristike;
	private JComboBox<String> funkcijaPosla;
	private JButton dodaj;
	private JButton snimiBatch;
	private String[] funkcijePosla = {"1","2","3"};
	private JTextArea tabelaH;
	private JTextField resursi;
	private JTextField ETA;
	private JLabel lblResursi;
	private JCheckBox E;
	private JTextField graf;
	private JButton loadOrder;
	private ArrayList<Job> jobs ;
	String toWrite ="";
	String heur = "";
	String eta = "";
	String gr = "";
	private MainFrame() {
		 super();
		 jobs = new ArrayList<Job>();
		 tabelaH = new JTextArea();
		 E = new JCheckBox("Ogranicenje prethodjenja");
		 graf = new JTextField("graf prethodjenja npr. 1,2,1,3");
		 tabelaH.setText("1 - H = a\n2 - H = C\n3 - H = d\n4 - H = d + W*C(W value)\n5 - H = Test\n6 - H = d + W*Test(W value)");
		 tabelaH.setEditable(false);
		 startnoVreme = new JTextField("startno vreme");
		 lblResursi = new JLabel("1. = 6 , 2 = 10 , 3 = 40");
		 resursi = new JTextField("Resursi koje job koristi navedeni kao nula ili 1 sa | izmedju");
		 ETA = new JTextField("najranije vreme koriscenja za svaki resurs");
		 vremeIzvrsavanja = new JTextField("vreme izvrsavanja");
		 deadLine = new JTextField("deadline");
		 heuristike = new JTextField("niz heuristickih funkcija");
		 funkcijaPosla = new JComboBox<String>(funkcijePosla);
		 dodaj = new JButton("Dodaj");
		 snimiBatch = new JButton("Snimi u batch");
		 dodaj.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				heur = heuristike.getText() + "\n";
				gr = graf.getText() + "\n";
				eta = ETA.getText() + "\n";
				toWrite += funkcijaPosla.getSelectedItem().toString()+"," + startnoVreme.getText()+","  + vremeIzvrsavanja.getText()+","  + deadLine.getText()+"," +resursi.getText()+"\n";
				heuristike.setEditable(false);
				ETA.setEditable(false);
			}
		});
		snimiBatch.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				try {
					int isE = 0;
					if(E.isSelected())isE=1;
					String path = "C://Users//laxy9//Desktop//batch.txt";
					FileWriter file = new FileWriter(path, true);
					PrintWriter pw = new PrintWriter(file);
					pw.append(heur + eta +  gr + isE + "\n"+ toWrite);
					
				//	System.out.println("Successfully Copied JSON Object to File...");
					file.close();
					pw.close();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				MainFrame.getInstance().dispose();
			}
		});
		
		 loadOrder = new JButton("Prikaz rasporeda");
		 loadOrder.addActionListener(new ActionListener() {
			 DisplayOrder ds;
			@Override
			public void actionPerformed(ActionEvent e) {
				java.io.File f = new java.io.File("C://Users//laxy9//Desktop//order.txt");
				java.util.Scanner sc=null;
				try {
					sc = new java.util.Scanner(f);
				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				while(sc.hasNextLine()) {
					Job j;
					String[] line = sc.nextLine().split(",");
					j = new Job(Integer.parseInt(line[0]), Integer.parseInt(line[1]), Integer.parseInt(line[2]));
					jobs.add(j);
					
				}
				// TODO Auto-generated method stub
				ds = new DisplayOrder(jobs);
				ds.setVisible(true);
			}
		});
		 setLayout(new GridLayout(5, 1, 20, 20));
		 add(tabelaH);add(heuristike);
		 add(startnoVreme);
		 add(vremeIzvrsavanja);
		 add(deadLine);
		 add(funkcijaPosla);
		 add(lblResursi);
		 add(resursi);
		 add(ETA);
		 add(graf);
		 add(E);
		 add(dodaj);
		 add(snimiBatch);
		 add(loadOrder);
		 setSize(1150, 700);
	} 

	

	public static MainFrame getInstance() {
		if (instance == null)instance = new MainFrame();
		return instance;
	}

}
