package view;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.GraphicsConfiguration;
import java.util.ArrayList;

public class DisplayGraphics extends Canvas{  
	
	private ArrayList<Job> jobs;
    
  public DisplayGraphics(ArrayList<Job> jobs) {
		super();
		this.jobs = jobs;
		// TODO Auto-generated constructor stub
	}

	public DisplayGraphics(GraphicsConfiguration config) {
		super(config);
		// TODO Auto-generated constructor stub
	}

public void paint(Graphics g) {  
      /*g.drawString("P1",50,140);  
      setBackground(Color.WHITE);  
      g.drawRect(50, 130,80, 40); */
      int i = 0;
      for (Job job : jobs) {
    	  g.drawString("P"+job.getId(),50+i,140);
    	  g.drawRect(50+i, 130,80, 40);
    	  g.drawString(String.valueOf(job.getStartTime()),50+i,180);
    	  //g.drawString(String.valueOf(job.getFinsihTime()),130+i,180);
    	  i+=80;
	}
      g.drawString(String.valueOf(jobs.get(jobs.size()-1).getFinsihTime()),130+i-80,180);
        
  }  
}