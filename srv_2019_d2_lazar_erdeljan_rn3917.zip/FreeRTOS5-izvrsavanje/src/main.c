
#include "vezba5.h"

int main( void )
{
	//U C projektu je dozvoljeno da postoji samo jedna main funkcija.
	main1();
}

