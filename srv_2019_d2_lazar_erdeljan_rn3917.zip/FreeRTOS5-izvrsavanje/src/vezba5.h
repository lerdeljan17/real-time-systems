/*
 * vezba5.h
 *
 * Ovo cemo da ukljucimo u main.c da bismo mu dali deklaracije za ostale main funkcije.
 */

#ifndef VEZBA5_H_
#define VEZBA5_H_

int main1();

#endif /* VEZBA5_H_ */
