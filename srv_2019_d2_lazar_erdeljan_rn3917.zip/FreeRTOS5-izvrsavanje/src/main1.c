/* Standard includes. */
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>
#include <assert.h>

/* FreeRTOS kernel includes. */
#include "FreeRTOS.h"
#include "task.h"

//#define a 1
#define BrResursa 3
//#define C 2
//#define d 3
#define dWC 4
#define NEW_STATE 0
#define RUNNING_STATE 1
#define FINISHED_STATE 2
#define rprintf(...) printf(__VA_ARGS__);fflush(stdout);
int ETA[BrResursa];
int resursi[BrResursa] = { 6, 10, 40 };
int heuristics[7] = { 0 };
int w = 0, wT = 0, E = 0;
int TaskETA[10] = {0};
TickType_t SF[20] = {0};
int PrecedenceEdges[50] = { 0 };
int pEdgesCount = 0;
struct BatchType_t batch;
struct JobType_t {
	void (*func)(void*);
	void *pvParameters;
	TickType_t xArrival;
	TickType_t xComputation;
	TickType_t xDeadline;
	char cState;
	TaskHandle_t xHandle;
	int resources[BrResursa];
};

struct BatchType_t {
	struct JobType_t *pxJobs;
	BaseType_t xJobCount;
	int *piJobOrder;
};

void vJobWrapper(void *pvParameters) {
	struct JobType_t *myJob = (struct JobType_t*) pvParameters;

	myJob->cState = RUNNING_STATE;

	myJob->func(myJob->pvParameters);

	myJob->cState = FINISHED_STATE;
	vTaskDelete(0);
}

void vMyScheduler(void *pvParameters) {
	struct BatchType_t *jobs = (struct BatchType_t*) pvParameters;
	int i;

	for (i = 0; i < jobs->xJobCount; i++) {
		//kreiramo FreeRTOS task za job i
		xTaskCreate(vJobWrapper, "", configMINIMAL_STACK_SIZE, jobs->pxJobs + i,
				1, &(jobs->pxJobs[i].xHandle));
	}

	for (i = 0; i < jobs->xJobCount; i++) {
		int currentTask = jobs->piJobOrder[i];
		rprintf("%d cuurentTask\n", currentTask);
		vTaskPrioritySet(jobs->pxJobs[currentTask].xHandle, 4);
	}

	for (;;) {
		vTaskDelay(1);
	}
}

void vJobCreate(struct JobType_t *job, void (*func)(void*), void *pvParameters,
		TickType_t arrival, TickType_t computation, TickType_t deadline,
		int resources[]) {
	job->func = func;
	job->pvParameters = pvParameters;
	job->xArrival = arrival;
	job->xComputation = computation;
	job->xDeadline = deadline;
	job->cState = NEW_STATE;
	job->xHandle = NULL;
	int i;
	for (i = 0; i < BrResursa; i++) {
		job->resources[i] = resources[i];
	}
}

void jobWork1(void *pvParameters) {
	char *msg = (char*) pvParameters;
	int i;

	for (i = 0; i < 20; i++) {
		rprintf(msg);
	}
	rprintf("\n");
}
void jobWork2(void *pvParameters) {
	int *n = (int*) pvParameters;
	int i, t1 = 0, t2 = 1, nextTerm;
	for (i = 1; i <= n; ++i) {
		rprintf("%d ", t1);
		nextTerm = t1 + t2;
		t1 = t2;
		t2 = nextTerm;
	}
	rprintf("\n");
}
void jobWork3(void *pvParameters) {
	int *radius = (int*) pvParameters;
	int area;
	int r = radius;
	//int r = *radius;
	//rprintf("dadas");
	// printf("\nEnter the radius of Circle : ");
	//scanf("%d", &radius);

	area = r * r;
	rprintf("Area of Circle : %d * Pi\n", area);
}

int* piJobOrderLDF(struct JobType_t *jobs, int jobCount, int *piPrecedenceEdges,
		int edgesCount) {
	int *flippedResult = (int*) malloc(jobCount * sizeof(int));
	int *result = (int*) malloc(jobCount * sizeof(int));

	int i, j;

	for (i = 0; i < jobCount; i++) {
		flippedResult[i] = -1;
	}

	for (i = 0; i < jobCount; i++) //nalazimo novi element za result
			{
		int jobIsNode[jobCount]; //0 ako je posao list, 1 ako je cvor, 2 ako je vec rasporedjen
		for (j = 0; j < jobCount; j++) {
			jobIsNode[j] = 0;
		}
		for (j = 0; j < jobCount; j++) {
			if (flippedResult[j] != -1) {
				jobIsNode[flippedResult[j]] = 2; //upisemo 2 za poslove koji su vec rasporedjeni
			}
		}

		for (j = 0; j < edgesCount; j += 2) //svaki element koji je cvor belezimo u jobIsNode
				{
			int jobId = piPrecedenceEdges[j] - 1;
			if (jobId > -1) {
				jobIsNode[jobId] = 1;
			}
		}

		int maxDeadline = 0;
		int maxDeadlineId = -1;

		for (j = 0; j < jobCount; j++) {
			if (jobIsNode[j] == 0) //job is leaf
					{
				if (jobs[j].xDeadline > maxDeadline) {
					maxDeadline = jobs[j].xDeadline;
					maxDeadlineId = j;
				}
			}
		}

		flippedResult[i] = maxDeadlineId;

		//brisanje iz grafa
		for (j = 0; j < edgesCount; j += 2) {
			if (piPrecedenceEdges[j + 1] == maxDeadlineId + 1) {
				piPrecedenceEdges[j] = 0;
				piPrecedenceEdges[j + 1] = 0;
			}
		}

	}

	for (i = 0; i < jobCount; i++) {
		result[i] = flippedResult[jobCount - i - 1];
	}

	return result;
}

int* piPrecedenceOrder(int *jobs, int jobCount,
		int *PrecedenceEdges, int edgesCount) {
	int *fResult = (int*) malloc(jobCount * sizeof(int));
	int *result = (int*) malloc(jobCount * sizeof(int));
	rprintf("uso u prethodjenje");
	int i, j;

	for (i = 0; i < jobCount; i++) //nalazimo novi element za result
			{
		int jobIsNode[jobCount]; //0 ako je posao list, 1 ako je cvor, 2 ako je vec rasporedjen
		for (j = 0; j < jobCount; j++) {
			jobIsNode[j] = 0;
		}
		for (j = 0; j < jobCount; j++) {
			if (result[j] != -1) {
				jobIsNode[result[j]] = 2; //upisemo 2 za poslove koji su vec rasporedjeni
			}
		}

		for (j = 0; j < edgesCount; j += 2) //svaki element koji je cvor belezimo u jobIsNode
				{
			int jobId = PrecedenceEdges[j] - 1;
			if (jobId > -1) {
				jobIsNode[jobId] = 1;
			}

			int LiD;
			for (j = 0; j < jobCount; j++) {
				if (jobIsNode[jobs[j]] == 0) //job is leaf
						{

					LiD = jobs[j];
					break;

				}
			}

			result[i] = LiD;

			//brisanje iz grafa
			for (j = 0; j < edgesCount; j += 2) {
				if (PrecedenceEdges[j + 1] == LiD + 1) {
					PrecedenceEdges[j] = 0;
					PrecedenceEdges[j + 1] = 0;
				}
			}

		}
			}

	for (i = 0; i < jobCount; i++) {
		fResult[i] = result[jobCount - i - 1];
	}

		return fResult;

}

int* piJobOrderA(struct JobType_t *jobs, int jobCount, int *piPrecedenceEdges,
		int edgesCount) {
	int minArrivalTime = INTMAX_MAX;
	struct JobType_t *jobsTMP = (struct JobType_t*) malloc(
			jobCount * sizeof(struct JobType_t));
	int minDeadlineId = -1;
	int j, i;
	int *result = (int*) malloc(jobCount * sizeof(int));
	for (i = 0; i < jobCount; i++) {
		jobsTMP[i] = jobs[i];
	}
	for (i = 0; i < jobCount; i++) {
		minArrivalTime = INTMAX_MAX;
		for (j = 0; j < jobCount; j++) {
			if (jobsTMP[j].xArrival == -1)
				continue;
			if (jobsTMP[j].xArrival < minArrivalTime) {
				minArrivalTime = jobsTMP[j].xArrival;
				minDeadlineId = j;
			}

		}
		result[i] = minDeadlineId;
		jobsTMP[minDeadlineId].xArrival = -1;

	}
	return result;

}
int* piJobOrderC(struct JobType_t *jobs, int jobCount, int *piPrecedenceEdges,
		int edgesCount) {
	int minArrivalTime = INTMAX_MAX;
	struct JobType_t *jobsTMP = (struct JobType_t*) malloc(
			jobCount * sizeof(struct JobType_t));
	int minDeadlineId = -1;
	int j, i;
	int *result = (int*) malloc(jobCount * sizeof(int));
	for (i = 0; i < jobCount; i++) {
		jobsTMP[i] = jobs[i];
	}
	for (i = 0; i < jobCount; i++) {
		minArrivalTime = INTMAX_MAX;
		for (j = 0; j < jobCount; j++) {
			if (jobsTMP[j].xComputation == -1)
				continue;
			if (jobsTMP[j].xComputation < minArrivalTime) {
				minArrivalTime = jobsTMP[j].xComputation;
				minDeadlineId = j;
			}

		}
		result[i] = minDeadlineId;
		jobsTMP[minDeadlineId].xComputation = -1;

	}
	return result;

}

int* piJobOrderD(struct JobType_t *jobs, int jobCount, int *piPrecedenceEdges,
		int edgesCount) {
	int minArrivalTime = INTMAX_MAX;
	struct JobType_t *jobsTMP = (struct JobType_t*) malloc(
			jobCount * sizeof(struct JobType_t));
	int minDeadlineId = -1;
	int j, i;
	int *result = (int*) malloc(jobCount * sizeof(int));
	for (i = 0; i < jobCount; i++) {
		jobsTMP[i] = jobs[i];
	}
	for (i = 0; i < jobCount; i++) {
		minArrivalTime = INTMAX_MAX;
		for (j = 0; j < jobCount; j++) {
			if (jobsTMP[j].xDeadline == -1)
				continue;
			if (jobsTMP[j].xDeadline < minArrivalTime) {
				minArrivalTime = jobsTMP[j].xDeadline;
				minDeadlineId = j;
			}

		}
		result[i] = minDeadlineId;
		jobsTMP[minDeadlineId].xDeadline = -1;

	}
	return result;

}
int* piJobOrderDWC(struct JobType_t *jobs, int jobCount, int *piPrecedenceEdges,
		int edgesCount) {
	int minArrivalTime = INTMAX_MAX;
	struct JobType_t *jobsTMP = (struct JobType_t*) malloc(
			jobCount * sizeof(struct JobType_t));
	int minDeadlineId = -1;
	int j, i;
	int *result = (int*) malloc(jobCount * sizeof(int));
	for (i = 0; i < jobCount; i++) {
		jobsTMP[i] = jobs[i];
	}
	for (i = 0; i < jobCount; i++) {
		minArrivalTime = INTMAX_MAX;
		for (j = 0; j < jobCount; j++) {
			if (jobsTMP[j].xDeadline + jobsTMP[j].xComputation * w
					< minArrivalTime) {
				minArrivalTime = jobsTMP[j].xDeadline
						+ jobsTMP[j].xComputation * w;
				minDeadlineId = j;
			}

		}
		result[i] = minDeadlineId;
		jobsTMP[minDeadlineId].xDeadline = LONG_MAX;

	}
	return result;

}
int maxEST(int niz[]) {
	int max = -1, i;
	for (i = 0; i < BrResursa; i++) {
		if (niz[i]) {
			//rprintf("uso %d ",niz[i]);
			if (ETA[i] > max) {
				max = ETA[i];
			}
		}
	}
	//rprintf("je max ETA %d ",max);
	return max;
}
int* piJobOrderTest(struct JobType_t *jobs, int jobCount,
		int *piPrecedenceEdges, int edgesCount) {
	int minArrivalTime = INTMAX_MAX;
	struct JobType_t *jobsTMP = (struct JobType_t*) malloc(
			jobCount * sizeof(struct JobType_t));
	int minDeadlineId = -1;
	int j, i;
	int *result = (int*) malloc(jobCount * sizeof(int));
	for (i = 0; i < jobCount; i++) {
		jobsTMP[i] = jobs[i];
	}
	for (i = 0; i < jobCount; i++) {
		minArrivalTime = INTMAX_MAX;
		for (j = 0; j < jobCount; j++) {
			if (max(jobsTMP[j].xArrival, maxEST(jobsTMP[j].resources))
					< minArrivalTime) {
				minArrivalTime = max(jobsTMP[j].xArrival,
						maxEST(jobsTMP[j].resources));
				minDeadlineId = j;
			}

		}
		TaskETA[i] = maxEST(jobsTMP[j].resources);
		result[i] = minDeadlineId;
		jobsTMP[minDeadlineId].xArrival = LONG_MAX;

	}
	return result;

}

int* piJobOrderDWTest(struct JobType_t *jobs, int jobCount,
		int *piPrecedenceEdges, int edgesCount) {
	int minArrivalTime = INTMAX_MAX;
	struct JobType_t *jobsTMP = (struct JobType_t*) malloc(
			jobCount * sizeof(struct JobType_t));
	int minDeadlineId = -1;
	int j, i;
	int *result = (int*) malloc(jobCount * sizeof(int));
	for (i = 0; i < jobCount; i++) {
		jobsTMP[i] = jobs[i];
	}
	for (i = 0; i < jobCount; i++) {
		minArrivalTime = INTMAX_MAX;
		for (j = 0; j < jobCount; j++) {
			if (jobsTMP[j].xDeadline+ wT * max(jobsTMP[j].xArrival, maxEST(jobsTMP[j].resources))
					< minArrivalTime) {
				minArrivalTime = jobsTMP[j].xDeadline+ wT* max(jobsTMP[j].xArrival, maxEST(jobsTMP[j].resources));
				minDeadlineId = j;
			}

		}
		TaskETA[i] = maxEST(jobsTMP[j].resources);
		result[i] = minDeadlineId;
		jobsTMP[minDeadlineId].xArrival = LONG_MAX;
		jobsTMP[minDeadlineId].xDeadline = LONG_MAX;

	}
	return result;

}

int checkOrder(int *order, int jobCount, struct JobType_t *jobs) {
	TickType_t sf;
	for(sf=0;sf<20;sf++){
		SF[sf]=0;
	}
	int i, gap;
	long s,f;
	TickType_t time = 0;
	for (i = 0; i < jobCount; i++) {
		gap = 0;
		if (jobs[order[i]].xArrival > time) {
			//gap = jobs[order[i]].xArrival - time;
			time = jobs[order[i]].xArrival;
			printf("%d", gap);
		}
		s = max(time,TaskETA[order[i]]);
		if (time + jobs[order[i]].xComputation + gap > jobs[order[i]].xDeadline) {
			rprintf("problem kod %d taska %d vreme jobC je %d i je %d (deadline je %d)\n",order[i], time, jobCount, i, jobs[order[i]].xDeadline);
			return 0;
		}
		time += gap + jobs[order[i]].xComputation;
		f = time;
		rprintf("Start %zu ,Finish %zu\n",s,f);
		SF[i*2] = s;
		SF[(i+1)*2] = f;
	}
	return 1;
}
char** str_split(char *a_str, const char a_delim) {
	char **result = 0;
	size_t count = 0;
	char *tmp = a_str;
	char *last_comma = 0;
	char delim[2];
	delim[0] = a_delim;
	delim[1] = 0;

	/* Count how many elements will be extracted. */
	while (*tmp) {
		if (a_delim == *tmp) {
			count++;
			last_comma = tmp;
		}
		tmp++;
	}

	/* Add space for trailing token. */
	count += last_comma < (a_str + strlen(a_str) - 1);

	/* Add space for terminating null string so caller
	 knows where the list of returned strings ends. */
	count++;

	result = malloc(sizeof(char*) * count);

	if (result) {
		size_t idx = 0;
		char *token = strtok(a_str, delim);

		while (token) {
			assert(idx < count);
			*(result + idx++) = strdup(token);
			token = strtok(0, delim);
		}
		assert(idx == count - 1);
		*(result + idx) = 0;
	}

	return result;
}
void read_file() {
	rprintf("\nUnesite putanju do prvog fajla: ");
	char path[100];
	fflush(stdin);
	gets(path);
	fflush(stdin);

	char heuristike[40];
	char resursi[30];
	char edges[50];
	char isE[2];
	int n, i = 0;
	char line[100];

	FILE *f1 = fopen(path, "r");
	fgets(heuristike, 100, f1);
	fgets(resursi, 30, f1);
	fgets(edges, 50, f1);
	fgets(isE, 2, f1);
	n = strlen(heuristike);
	heuristike[n - 1] = '\0';
	n = strlen(resursi);
	resursi[n - 1] = '\0';
	n = strlen(edges);
	edges[n - 1] = '\0';
//	n = strlen(isE);
//	isE[n - 1] = '\0';
	n = 0;

	if (strcmp(isE, "1") == 0)
		E = 1;
	if (strcmp(isE, "0") == 0)
		E = 0;

	printf("isE : %s	E : %d\n ", isE, E);
	int brk = 0;
	char **tokens;
	tokens = str_split(edges, ',');
	if (tokens) {

		int i;
		for (i = 0; *(tokens + i); i++) {

			brk = strtol(*(tokens + i), (tokens + i), 10);
			rprintf("node=[%ld] ", brk);
			free(*(tokens + i));
			PrecedenceEdges[i] = brk;
			pEdgesCount++;

		}
		rprintf("\n");
		free(tokens);
	}
	//pEdgesCount/=2;

	while (heuristike[i] != '\0') {
		if (isdigit(heuristike[i]) && heuristike[i] != '4') {
			heuristics[n] = heuristike[i] - '0';
			rprintf("%d ", heuristics[n]);
			n++;
			i++;
		} else if (isdigit(heuristike[i]) && heuristike[i] == '4') {
			heuristics[n] = heuristike[i] - '0';
			n++;
			i += 2;
			while (heuristike[i] != ')') {
				w = w * 10 + heuristike[i] - '0';
				i++;
			}
		} else if (isdigit(heuristike[i]) && heuristike[i] == '6') {
			heuristics[n] = heuristike[i] - '0';
			n++;
			i += 2;
			while (heuristike[i] != ')') {
				wT = wT * 10 + heuristike[i] - '0';
				i++;
			}
		} else {
			i++;
		}
	}

	long br = 0, jobC = 0;
	int res[BrResursa];
//	tokens;
	tokens = str_split(resursi, ',');
	if (tokens) {
		int i;
		for (i = 0; *(tokens + i); i++) {
			br = strtol(*(tokens + i), (tokens + i), 10);
			rprintf("ETA=[%ld]\n", br);
			free(*(tokens + i));
			ETA[i] = br;

		}
		rprintf("\n");
		free(tokens);
	}

	//rprintf("fda");
	int args[4];
	int st;
	for(st = 0; st < 4; st++){
		args[st] = 0;
	}
	int k = 0;
	rprintf("%d isE\n", E);
	batch.pxJobs = (struct JobType_t*) malloc(6 * sizeof(struct JobType_t));
	fgets(line, 100, f1);
	while (!feof(f1)) {
		if (fgets(line, 100, f1)) {
			rprintf("linija %s", line);
			br = 0;
			char **tokens;
			tokens = str_split(line, ',');
			if (tokens) {

				int i;
				for (i = 0; *(tokens + i); i++) {

					if (i == 4) {
						k = 0;
						int m = 0;
						while (k < BrResursa) {
							if ((*(tokens + i))[m] != '|') {
								//rprintf("afaf");
								//rprintf("tokeni %c\n",(*(tokens + i))[m]);
								res[k] = (*(tokens + i))[m] - '0';
								rprintf("res=[%ld]\n", res[k]);
								k++;
							}
							m++;
						}
					} else {
						br = strtol(*(tokens + i), (tokens + i), 10);
						rprintf("arg=[%ld]\n", br);
						free(*(tokens + i));
						args[i] = br;
					}

				}
				rprintf("\n");
				free(tokens);
			}
			struct JobType_t job;
			long a = args[1];
			long c = args[2];
			long d = args[3];
			if (args[0] == 1) {
				vJobCreate(&job, jobWork1, "|", a, c, d, res);
				rprintf("iz ucitavanja %ld\n", job.xArrival);
			} else if (args[0] == 2) {
				vJobCreate(&job, jobWork2, 6, a, c, d, res);
				//rprintf("%ld",job.xArrival);
				/*rprintf("%d ",job.resources[0]);
				 rprintf("%d ",job.resources[1]);
				 rprintf("%d ",job.resources[2]);*/
			} else if (args[0] == 3) {
				vJobCreate(&job, jobWork3, 4, a, c, d, res);
			}
			batch.pxJobs[jobC] = job;
			rprintf("dodat na %ld sa deadline %ld\n", jobC,
					batch.pxJobs[jobC].xDeadline);
			jobC++;

		}
	}
	batch.xJobCount = jobC;

	/*for(i=0;i<7;i++){
	 rprintf("%d",heuristics[i]);
	 }
	 rprintf("\n W je %d ",w);
	 rprintf("\n");*/
	fclose(f1);
}
void printOrder(void *pvParameters) {
	struct BatchType_t *jobs = (struct BatchType_t*) pvParameters;
	FILE *f = fopen("C://Users//laxy9//Desktop//order.txt", "w");
	TickType_t i = 0;
	char jobToW[30];
	char id[2], start[5], finish[6];
	int currentJob = jobs->piJobOrder[0];
	for (i = 0; i < batch.xJobCount; i++) {
		rprintf("%ld ", jobs->pxJobs[i].xDeadline);
	}
	rprintf("\n");
	/*itoa(currentJob, id, 10);
	itoa(SF[0], start, 10);
	//rprintf("%d arrival prvog je \n",jobs->pxJobs[currentJob].xArrival);
	itoa(SF[1], finish, 10);
	fputs(id, f);
	fputc(',', f);
	fputs(start, f);
	fputc(',', f);
	fputs(finish, f);
	fputc('\n', f);*/

	for (i = 0; i < jobs->xJobCount; i++) {
		//int prevJob = jobs->piJobOrder[i - 1];
		currentJob = jobs->piJobOrder[i];
		itoa(currentJob, id, 10);
		itoa(SF[i*2], start, 10);
		itoa(SF[(i+1)*2], finish, 10);
		fputs(id, f);
		fputc(',', f);
		fputs(start, f);
		fputc(',', f);
		fputs(finish, f);
		fputc('\n', f);
	}

	fclose(f);
}

int main1(void) {
	//1. definisemo poslove
	/*struct JobType_t job1, job2, job3, job4, job5, job6;
	 vJobCreate(&job1, jobWork1, ".", 90,30, 200);
	 vJobCreate(&job2, jobWork2, 5, 30,10, 200);//ovde 80 za Ci ne prolazi
	 vJobCreate(&job3, jobWork3, 4, 70,70, 200);*/
	/*vJobCreate(&job4, jobWork, "*", 0, 80,100);
	 vJobCreate(&job5, jobWork, "?", 0, 20,100);
	 vJobCreate(&job6, jobWork, "%%", 0,10 ,60);*/
	//. * |  ? - %%
	read_file();
	int po;
	for (po = 0; po < batch.xJobCount; po++) {
		rprintf("pxJobs %d ", batch.pxJobs[po].xDeadline);
	}
	rprintf("\n");
	//struct BatchType_t batch;
	/*batch.pxJobs = (struct JobType_t*) malloc(6 * sizeof(struct JobType_t));
	 batch.xJobCount = 3;
	 batch.pxJobs[0] = job1;
	 batch.pxJobs[1] = job2;
	 batch.pxJobs[2] = job3;*/
	/*batch.pxJobs[3] = job4;
	 batch.pxJobs[4] = job5;
	 batch.pxJobs[5] = job6;*/
	//neparni brojevi su prethodnici
	//parni brojevi su sledbenici
	//brojevi su logicki indeksi poslova - treba oduzeti 1 za pristup nizu
	int piPrecedenceEdges[] = { 1, 2, 1, 3, 2, 4, 2, 5, 3, 6 };
	int j = 0;
	int orderOK = 0;
	int *jobOrder;
	//int *jobOrder = piJobOrder(batch.pxJobs, batch.xJobCount, piPrecedenceEdges,10);
	for (j = 0; j < 7; j++) {
		jobOrder = NULL;
		if (heuristics[j] == 1) {
			//rprintf("fsd");
			jobOrder = piJobOrderA(batch.pxJobs, batch.xJobCount,
					piPrecedenceEdges, 10);
			if (E)
				jobOrder = piPrecedenceOrder(jobOrder, batch.xJobCount,
						PrecedenceEdges, pEdgesCount);
		} else if (heuristics[j] == 2) {
			jobOrder = piJobOrderC(batch.pxJobs, batch.xJobCount,
					piPrecedenceEdges, 10);
			if (E)
				jobOrder = piPrecedenceOrder(jobOrder, batch.xJobCount,
						PrecedenceEdges, pEdgesCount);
		} else if (heuristics[j] == 3) {
			jobOrder = piJobOrderD(batch.pxJobs, batch.xJobCount,
					piPrecedenceEdges, 10);
			if (E)
				jobOrder = piPrecedenceOrder(jobOrder, batch.xJobCount,
						PrecedenceEdges, pEdgesCount);
		} else if (heuristics[j] == 4) {
			jobOrder = piJobOrderDWC(batch.pxJobs, batch.xJobCount,
					piPrecedenceEdges, 10);
			if (E)
				jobOrder = piPrecedenceOrder(jobOrder, batch.xJobCount,
						PrecedenceEdges, pEdgesCount);
		} else if (heuristics[j] == 5) {
			jobOrder = piJobOrderTest(batch.pxJobs, batch.xJobCount,
					piPrecedenceEdges, 10);
			if (E)
				jobOrder = piPrecedenceOrder(jobOrder, batch.xJobCount,
						PrecedenceEdges, pEdgesCount);
		} else if (heuristics[j] == 6) {
			jobOrder = piJobOrderDWTest(batch.pxJobs, batch.xJobCount,
					piPrecedenceEdges, 10);
			if (E)
				jobOrder = piPrecedenceOrder(jobOrder, batch.xJobCount,
						PrecedenceEdges, pEdgesCount);
		} else {
			continue;
		}

		int i;

		for (i = 0; i < batch.xJobCount; i++) {
			rprintf("%d ", jobOrder[i]);
		}
		rprintf("\n");

		batch.piJobOrder = jobOrder;
		if (!checkOrder(jobOrder, batch.xJobCount, batch.pxJobs)) {
			rprintf("Nije moguc raspored\n");
			orderOK = 0;
			continue;
		}

		orderOK = 1;
		printOrder(&batch);
		/*if(!orderOK){
		 //printf("Nije moguc raspored");
		 return 0;
		 }*/

		//2. kreiramo nas rasporedjivac
		xTaskCreate(vMyScheduler, "", configMINIMAL_STACK_SIZE, &batch, 3,
				NULL);

		vTaskStartScheduler();

		return 0;
	}
	return 0;
}

